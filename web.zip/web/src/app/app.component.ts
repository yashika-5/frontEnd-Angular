import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'web';
  playing = true;
  celOrfore = true;
  value=24;
  button1;
  loading = true;
  ngOnInit(){
    
   setTimeout(() => {
     this.loading = false;
   }, 3000);
  }
 
  play(){
    this.playing = true;
  }
 
  pause()
  {
    this.playing = false;
  }
  temperature(){
    this.celOrfore = true;
    this.value = 24;
    this.button1

  }
  temp(){
    this.celOrfore = false;
    this.value = 75.2;
  }
  
}
